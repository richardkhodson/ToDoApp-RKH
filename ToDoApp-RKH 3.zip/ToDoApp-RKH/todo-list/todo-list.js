(function() {

    angular.module('myApp')
        .component('todoList', { // the tag for using this is <char-detail>
            templateUrl: "todo-list/todo-list.html",
            controller: todoListsController,
            bindings: {
                list: '<', // input object binding
                onClose: '&'    // output binding
            }
        });

    function todoListsController(listService) {
        var self = this;
        self.tolist = listService.lists;
        self.close = close;
        self.todoAdd = function(taskName) {
            if (!self.todoInput) {
                return;
            }
        self.list.todos.push({todoText: taskName, done:false});
        self.todoInput = "";
        };

        self.remove = function() {
            var oldList = self.list.todos;
            console.log(oldList);
            self.list.todos = [];
            angular.forEach(oldList, function (x) {
                if (!x.done) self.list.todos.push(x);
            });
        };
        /*$scope.remove = function(index) {
            $scope.skills.splice(index, 1);
        }*/

        function close() {
            //self.list = undefined;
            self.onClose();
        }
    }

})();
    
  
