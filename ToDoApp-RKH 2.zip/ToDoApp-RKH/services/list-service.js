
(function(){
    angular.module('myApp')
        .service('listService', listService);
    

        
    function listService($localStorage) {
        var self = this;
        var lists = [];

        if ($localStorage.lists) {
            lists = $localStorage.lists
        }
        else {
            lists = [
                {
                    "name": "Example List", "todos": []
                },

                {
                    "name": "Honey Do", "todos": []

                },
                {
                    "name": "Garage", "todos": []

                },
                {
                    "name": "Yard Work", "todos": []

                },
                {
                    "name": "Saturday", "todos": []

                },
                {
                    "name": "Car Issues", "todos": []

                }
            ];
            $localStorage.lists = lists;

        }
        
        // sample data from swapi.co


        this.addList = function (listName) {
            lists.push({
                "name": listName, "todos": []
            });
        };

        this.getLists= function() {
            return lists;
        }

    }
})();
