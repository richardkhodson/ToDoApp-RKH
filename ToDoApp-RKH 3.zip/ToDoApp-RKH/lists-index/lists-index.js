(function () {

    angular.module('myApp')
        .component('listsIndex', { // the tag for using this is <lists-index>
            templateUrl: "lists-index/lists-index.html",
            controller: listsIndexController
        })
        .config(listsIndexConfig);

    function listsIndexConfig($stateProvider) {
        $stateProvider.state('main', {
            url: '/main',
            template: '<lists-index></lists-index>'
        });
    }

    function listsIndexController(listService) {
        // variables
        var self = this;
        self.orderBy = 'name';
        self.sortClass = 'sort-asc';
        self.selectedList = undefined;
        self.sort = sort;
        self.selectList = selectList;
        self.close = close;
        self.listAdd = listAdd;
        self.lists = listService.getLists();

        function sort(attribute) {
            self.sortClass = 'sort-asc'; // down arrow
            var newOrderBy = attribute;
            if (self.orderBy === attribute) {
                newOrderBy = '-' + attribute;
                self.sortClass = 'sort-desc';
            }
            self.orderBy = newOrderBy;
        }

        function selectList(list) {
            self.selectedList = list;
        }

        function listAdd(newList) {
            if (!newList) {
                return;
            }
            listService.addList(newList);
            self.listInput = "";
        }

        self.remove = function() {
            var oldList = self.newList;
            console.log(oldList);
            self.newList= [];
            angular.forEach(oldList, function (x) {
                if (!x.done) self.newList.push(x);
            });
        };

        function close() {
            self.selectedList = undefined;
        }


    }

})();


